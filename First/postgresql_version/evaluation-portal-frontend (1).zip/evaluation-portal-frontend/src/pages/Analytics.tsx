import { useAuth } from '../auth/AuthContext';
import { useFetch } from '../api/useFetch';
import { Empty, ErrorBox, Loading } from '../components/ui';
import { Status, STATUS_LABEL } from '../api/types';

/**
 * Expected response of GET /analytics/department (HOD) or /analytics/overview (ADMIN):
 * { statusCounts: {DRAFT:n,...}, avgReviewHours: n, returnRate: 0..1, totalSchemes: n,
 *   pendingFaculty: [{name, drafts, returned}], hoursByCourse: [{course, hours}],
 *   turnaroundTrend: [{label, hours}] }
 * All fields optional; missing ones are simply not drawn.
 */
const COLORS: Record<Status, string> = { DRAFT: 'var(--ink2)', SUBMITTED: 'var(--info)', UNDER_REVIEW: 'var(--warn)', APPROVED: 'var(--ok)', RETURNED_FOR_CORRECTION: 'var(--bad)' };

function Bars({ rows, color = 'var(--accent)', unit = '' }: { rows: { label: string; value: number; color?: string }[]; color?: string; unit?: string }) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  return (
    <div role="list">
      {rows.map((r) => (
        <div role="listitem" key={r.label} className="row" style={{ marginBottom: '.4rem', flexWrap: 'nowrap' }}>
          <span style={{ width: 150, flexShrink: 0 }} className="muted">{r.label}</span>
          <div style={{ flex: 1, background: 'var(--paper)', borderRadius: 4, height: 18 }}>
            <div style={{ width: `${(r.value / max) * 100}%`, height: '100%', background: r.color ?? color, borderRadius: 4, minWidth: r.value ? 4 : 0 }} />
          </div>
          <strong style={{ width: 70, textAlign: 'right' }}>{r.value}{unit}</strong>
        </div>))}
    </div>
  );
}

export default function Analytics() {
  const { user } = useAuth();
  const { data: d, loading, error } = useFetch<any>(user!.role === 'ADMIN' ? '/analytics/overview' : '/analytics/department');
  if (loading && !d) return <Loading />;
  const statuses = (Object.keys(STATUS_LABEL) as Status[]).map((s) => ({ label: STATUS_LABEL[s], value: d?.statusCounts?.[s] ?? 0, color: COLORS[s] }));
  const total = d?.totalSchemes ?? statuses.reduce((a, b) => a + b.value, 0);
  const approvedPct = total ? Math.round(((d?.statusCounts?.APPROVED ?? 0) / total) * 100) : 0;

  return (
    <>
      <h1>Analytics</h1>
      <p className="muted">{user!.role === 'ADMIN' ? 'All departments' : 'Your department'}</p>
      <ErrorBox msg={error} />
      {!d ? <Empty>No analytics available yet.</Empty> : (<>
        <div className="grid" style={{ margin: '1rem 0' }}>
          <div className="stat"><b>{total}</b><span className="muted">Schemes</span></div>
          <div className="stat"><b>{approvedPct}%</b><span className="muted">Approved</span></div>
          <div className="stat"><b>{d.avgReviewHours != null ? `${Math.round(d.avgReviewHours)} h` : '—'}</b><span className="muted">Average time to approval</span></div>
          <div className="stat"><b>{d.returnRate != null ? `${Math.round(d.returnRate * 100)}%` : '—'}</b><span className="muted">Returned at least once</span></div>
        </div>
        <div className="card"><h2>Schemes by status</h2><Bars rows={statuses} /></div>
        {d.turnaroundTrend?.length > 0 && <div className="card"><h2>Review turnaround by month</h2><Bars unit=" h" rows={d.turnaroundTrend.map((t: any) => ({ label: t.label, value: Math.round(t.hours) }))} /></div>}
        {d.hoursByCourse?.length > 0 && <div className="card"><h2>Planned hours by course</h2><Bars rows={d.hoursByCourse.map((c: any) => ({ label: c.course, value: c.hours }))} /></div>}
        {d.pendingFaculty?.length > 0 && (
          <div className="card"><h2>Faculty with work outstanding</h2>
            <div className="scroll"><table><thead><tr><th>Faculty</th><th>Drafts</th><th>Returned</th></tr></thead>
              <tbody>{d.pendingFaculty.map((f: any) => <tr key={f.name}><td>{f.name}</td><td>{f.drafts ?? 0}</td><td>{f.returned ?? 0}</td></tr>)}</tbody></table></div></div>)}
      </>)}
    </>
  );
}
