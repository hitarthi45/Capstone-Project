export interface FieldCfg {
  name: string; label: string;
  type?: 'text' | 'number' | 'password' | 'select' | 'checkbox';
  options?: string[];                                  // static select options
  ref?: { path: string; label: (r: any) => string };   // select options loaded from another endpoint
  createOnly?: boolean; optional?: boolean;
}
export interface ResCfg { path: string; title: string; columns: { label: string; render(r: any): any }[]; fields: FieldCfg[] }

export const adminResources: ResCfg[] = [
  { path: 'users', title: 'Users',
    columns: [{ label: 'Name', render: (r) => r.name }, { label: 'Email', render: (r) => r.email }, { label: 'Role', render: (r) => r.role }, { label: 'Active', render: (r) => (r.isActive ? 'Yes' : 'No') }],
    fields: [
      { name: 'name', label: 'Name' }, { name: 'email', label: 'Email' },
      { name: 'password', label: 'Password', type: 'password', createOnly: true },
      { name: 'role', label: 'Role', type: 'select', options: ['ADMIN', 'HOD', 'FACULTY'] },
      { name: 'departmentId', label: 'Department', type: 'select', ref: { path: 'departments', label: (r) => `${r.code} – ${r.name}` }, optional: true },
      { name: 'isActive', label: 'Active', type: 'checkbox' },
    ] },
  { path: 'departments', title: 'Departments',
    columns: [{ label: 'Code', render: (r) => r.code }, { label: 'Name', render: (r) => r.name }, { label: 'HOD', render: (r) => r.hod?.name ?? '—' }],
    fields: [{ name: 'name', label: 'Name' }, { name: 'code', label: 'Code' }, { name: 'hodId', label: 'Head of department', type: 'select', ref: { path: 'users', label: (r) => `${r.name} (${r.role})` }, optional: true }] },
  { path: 'programs', title: 'Programs',
    columns: [{ label: 'Name', render: (r) => r.name }, { label: 'Department', render: (r) => r.department?.name ?? r.departmentId }],
    fields: [{ name: 'name', label: 'Name' }, { name: 'departmentId', label: 'Department', type: 'select', ref: { path: 'departments', label: (r) => r.name } }] },
  { path: 'semesters', title: 'Semesters',
    columns: [{ label: 'Number', render: (r) => r.number }, { label: 'Academic year', render: (r) => r.academicYear }, { label: 'Program', render: (r) => r.program?.name ?? r.programId }],
    fields: [{ name: 'number', label: 'Semester number', type: 'number' }, { name: 'academicYear', label: 'Academic year (e.g. 2025-26)' }, { name: 'programId', label: 'Program', type: 'select', ref: { path: 'programs', label: (r) => r.name } }] },
  { path: 'courses', title: 'Courses',
    columns: [{ label: 'Code', render: (r) => r.code }, { label: 'Title', render: (r) => r.title }, { label: 'Type', render: (r) => r.type }, { label: 'Credits', render: (r) => r.credits }, { label: 'L-T-P', render: (r) => `${r.L}-${r.T}-${r.P}` }],
    fields: [
      { name: 'code', label: 'Code' }, { name: 'title', label: 'Title' },
      { name: 'type', label: 'Type', type: 'select', options: ['CORE', 'ELECTIVE', 'LAB'] },
      { name: 'credits', label: 'Credits', type: 'number' }, { name: 'L', label: 'Lecture hours (L)', type: 'number' },
      { name: 'T', label: 'Tutorial hours (T)', type: 'number' }, { name: 'P', label: 'Practical hours (P)', type: 'number' },
      { name: 'semesterId', label: 'Semester', type: 'select', ref: { path: 'semesters', label: (r) => `Sem ${r.number} – ${r.academicYear}` } },
    ] },
  { path: 'course-assignments', title: 'Course assignments',
    columns: [{ label: 'Course', render: (r) => `${r.course?.code ?? ''} ${r.course?.title ?? r.courseId}` }, { label: 'Faculty', render: (r) => r.faculty?.name ?? r.facultyId }, { label: 'Academic year', render: (r) => r.academicYear }],
    fields: [
      { name: 'courseId', label: 'Course', type: 'select', ref: { path: 'courses', label: (r) => `${r.code} – ${r.title}` } },
      { name: 'facultyId', label: 'Faculty', type: 'select', ref: { path: 'users', label: (r) => `${r.name} (${r.role})` } },
      { name: 'academicYear', label: 'Academic year' },
    ] },
];
