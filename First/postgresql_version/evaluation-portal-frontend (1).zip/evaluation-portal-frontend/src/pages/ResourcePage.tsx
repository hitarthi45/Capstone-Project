import { FormEvent, useState } from 'react';
import { api, errMsg } from '../api/client';
import { useFetch } from '../api/useFetch';
import { Empty, ErrorBox, Field, Loading, Modal, Pager } from '../components/ui';
import { FieldCfg, ResCfg } from './adminConfig';

/** One generic admin CRUD screen, driven by the config in adminConfig.ts. */
export default function ResourcePage({ cfg }: { cfg: ResCfg }) {
  const [page, setPage] = useState(1);
  const { data, meta, loading, error, reload } = useFetch<any[]>(`/${cfg.path}`, { page, limit: 10 });
  const [editing, setEditing] = useState<any | null>(null); // {} = create
  return (
    <div key={cfg.path}>
      <div className="row between"><h1>{cfg.title}</h1><button className="btn" onClick={() => setEditing({})}>Add new</button></div>
      <ErrorBox msg={error} />
      {loading && !data ? <Loading /> : !data?.length ? <Empty>Nothing here yet. Add the first one.</Empty> : (
        <div className="scroll" style={{ marginTop: '1rem' }}><table>
          <thead><tr>{cfg.columns.map((c) => <th key={c.label}>{c.label}</th>)}<th /></tr></thead>
          <tbody>{data.map((r) => (
            <tr key={r.id}>
              {cfg.columns.map((c) => <td key={c.label}>{c.render(r)}</td>)}
              <td className="row" style={{ justifyContent: 'flex-end' }}>
                <button className="btn ghost sm" onClick={() => setEditing(r)}>Edit</button>
                <button className="btn ghost sm" onClick={async () => {
                  if (!confirm('Delete this record?')) return;
                  try { await api.del(`/${cfg.path}/${r.id}`); reload(); } catch (e) { alert(errMsg(e)); }
                }}>Delete</button>
              </td>
            </tr>))}</tbody>
        </table></div>)}
      <Pager meta={meta} onPage={setPage} />
      {editing && <FormModal cfg={cfg} record={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); reload(); }} />}
    </div>
  );
}

function RefSelect({ f, value, onChange }: { f: FieldCfg; value: any; onChange(v: string): void }) {
  const { data } = useFetch<any[]>(`/${f.ref!.path}`, { limit: 100 });
  return (
    <select value={value ?? ''} onChange={(e) => onChange(e.target.value)} required={!f.optional}>
      <option value="">{f.optional ? 'None' : 'Select…'}</option>
      {(data ?? []).map((r) => <option key={r.id} value={r.id}>{f.ref!.label(r)}</option>)}
    </select>
  );
}

function FormModal({ cfg, record, onClose, onSaved }: { cfg: ResCfg; record: any; onClose(): void; onSaved(): void }) {
  const isEdit = !!record.id;
  const [v, setV] = useState<Record<string, any>>(() => ({ isActive: true, ...record }));
  const [err, setErr] = useState<string>();
  const set = (k: string, val: any) => setV((p) => ({ ...p, [k]: val }));

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(undefined);
    const body: Record<string, any> = {};
    for (const f of cfg.fields) {
      if (f.createOnly && isEdit) continue;
      let x = v[f.name];
      if (f.type === 'number') x = x === '' || x == null ? undefined : Number(x);
      if (x === '' || x === undefined) { if (f.optional) body[f.name] = null; continue; }
      body[f.name] = x;
    }
    try { isEdit ? await api.patch(`/${cfg.path}/${record.id}`, body) : await api.post(`/${cfg.path}`, body); onSaved(); }
    catch (e2) { setErr(errMsg(e2)); }
  };

  return (
    <Modal title={`${isEdit ? 'Edit' : 'New'} ${cfg.title.toLowerCase().replace(/s$/, '')}`} onClose={onClose}>
      <form onSubmit={submit}>
        <ErrorBox msg={err} />
        {cfg.fields.filter((f) => !(f.createOnly && isEdit)).map((f) => (
          <Field key={f.name} label={f.label}>
            {f.type === 'checkbox' ? <input type="checkbox" style={{ width: 'auto' }} checked={!!v[f.name]} onChange={(e) => set(f.name, e.target.checked)} />
              : f.ref ? <RefSelect f={f} value={v[f.name]} onChange={(x) => set(f.name, x)} />
              : f.type === 'select' ? <select value={v[f.name] ?? ''} onChange={(e) => set(f.name, e.target.value)} required><option value="">Select…</option>{f.options!.map((o) => <option key={o}>{o}</option>)}</select>
              : <input type={f.type ?? 'text'} value={v[f.name] ?? ''} onChange={(e) => set(f.name, e.target.value)} required={!f.optional} />}
          </Field>))}
        <button className="btn">Save changes</button>
      </form>
    </Modal>
  );
}
