import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useFetch } from '../api/useFetch';
import { Empty, ErrorBox, Loading, Pager, StatusBadge } from '../components/ui';
import { fmtDate, Status, STATUS_LABEL } from '../api/types';

export default function SchemeList() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const { data, meta, loading, error } = useFetch<any[]>('/teaching-schemes', { page, limit: 10, status: status || undefined, search: search || undefined });

  return (
    <>
      <div className="row between">
        <h1>Teaching schemes</h1>
        {user!.role === 'FACULTY' && <Link className="btn" to="/schemes/new">New scheme</Link>}
      </div>
      <div className="row" style={{ margin: '1rem 0' }}>
        <input style={{ maxWidth: 280 }} placeholder="Search course or faculty" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
        <select style={{ maxWidth: 200 }} value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">All statuses</option>
          {(Object.keys(STATUS_LABEL) as Status[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
        </select>
      </div>
      <ErrorBox msg={error} />
      {loading && !data ? <Loading /> : !data?.length ? <Empty>No schemes match. {user!.role === 'FACULTY' && 'Create one to get started.'}</Empty> : (
        <div className="scroll"><table>
          <thead><tr><th>Course</th><th>Faculty</th><th>Status</th><th>Version</th><th>Submitted</th></tr></thead>
          <tbody>{data.map((s) => (
            <tr key={s.id} className="click" onClick={() => nav(`/schemes/${s.id}`)}>
              <td><strong>{s.courseAssignment?.course?.code}</strong> {s.courseAssignment?.course?.title}</td>
              <td>{s.courseAssignment?.faculty?.name ?? '—'}</td>
              <td><StatusBadge status={s.status} /></td>
              <td>v{s.currentVersion ?? 0}</td>
              <td>{fmtDate(s.submittedAt)}</td>
            </tr>))}</tbody>
        </table></div>
      )}
      <Pager meta={meta} onPage={setPage} />
    </>
  );
}
