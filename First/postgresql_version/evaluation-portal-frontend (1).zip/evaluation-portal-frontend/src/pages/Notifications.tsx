import { useNavigate } from 'react-router-dom';
import { api } from '../api/client';
import { useFetch } from '../api/useFetch';
import { Empty, ErrorBox, Loading } from '../components/ui';
import { fmtDate } from '../api/types';

export default function Notifications() {
  const nav = useNavigate();
  const { data, loading, error, reload } = useFetch<any[]>('/notifications');
  const open = async (n: any) => {
    if (!n.isRead) await api.patch(`/notifications/${n.id}/read`);
    if (n.schemeId) nav(`/schemes/${n.schemeId}`); else reload();
  };
  return (
    <>
      <div className="row between">
        <h1>Notifications</h1>
        <button className="btn ghost" onClick={async () => { await api.patch('/notifications/read-all'); reload(); }}>Mark all read</button>
      </div>
      <ErrorBox msg={error} />
      {loading && !data ? <Loading /> : !data?.length ? <Empty>You're all caught up.</Empty> : data.map((n) => (
        <div key={n.id} className="card" style={{ cursor: 'pointer', borderLeft: n.isRead ? undefined : '4px solid var(--accent)' }} onClick={() => open(n)}>
          <div>{n.message}</div><small className="muted">{fmtDate(n.createdAt)}</small>
        </div>))}
    </>
  );
}
