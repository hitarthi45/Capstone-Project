import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useFetch } from '../api/useFetch';
import { ErrorBox, Loading } from '../components/ui';

const pretty = (k: string) => k.replace(/([A-Z])/g, ' $1').replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase());

/** Renders whatever stats the dashboard endpoint returns: numbers become tiles, objects become small tables. */
export default function Dashboard() {
  const { user } = useAuth();
  const { data, loading, error } = useFetch<Record<string, any>>(`/dashboard/${user!.role.toLowerCase()}`);
  const entries = Object.entries(data ?? {});
  return (
    <>
      <h1>Hello, {user!.name}</h1>
      <p className="muted">
        {user!.role === 'FACULTY' && 'Track your teaching schemes and respond to HOD comments.'}
        {user!.role === 'HOD' && 'Schemes waiting for review in your department.'}
        {user!.role === 'ADMIN' && 'System overview.'}
      </p>
      <div className="row" style={{ margin: '1rem 0' }}>
        <Link className="btn" to="/schemes">Open schemes</Link>
        {user!.role === 'FACULTY' && <Link className="btn ghost" to="/schemes/new">New scheme</Link>}
      </div>
      <ErrorBox msg={error} />
      {loading && <Loading />}
      <div className="grid">
        {entries.filter(([, v]) => typeof v === 'number').map(([k, v]) => <div className="stat" key={k}><b>{v}</b><span className="muted">{pretty(k)}</span></div>)}
      </div>
      {entries.filter(([, v]) => v && typeof v === 'object').map(([k, v]) => (
        <div className="card" key={k}>
          <h2>{pretty(k)}</h2>
          {Array.isArray(v)
            ? <pre>{JSON.stringify(v, null, 2)}</pre>
            : <table><tbody>{Object.entries(v).map(([a, b]) => <tr key={a}><td>{pretty(a)}</td><td>{String(b)}</td></tr>)}</tbody></table>}
        </div>
      ))}
    </>
  );
}
