import { useState } from 'react';
import { useFetch } from '../api/useFetch';
import { Empty, ErrorBox, Loading, Pager } from '../components/ui';
import { fmtDate } from '../api/types';

export default function AuditLogs() {
  const [page, setPage] = useState(1);
  const [action, setAction] = useState('');
  const [entity, setEntity] = useState('');
  const { data, meta, loading, error } = useFetch<any[]>('/audit-logs', { page, limit: 20, action: action || undefined, entity: entity || undefined });
  return (
    <>
      <h1>Audit log</h1>
      <div className="row" style={{ margin: '1rem 0' }}>
        <input style={{ maxWidth: 200 }} placeholder="Action (e.g. APPROVE)" value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }} />
        <input style={{ maxWidth: 200 }} placeholder="Entity (e.g. TeachingScheme)" value={entity} onChange={(e) => { setEntity(e.target.value); setPage(1); }} />
      </div>
      <ErrorBox msg={error} />
      {loading && !data ? <Loading /> : !data?.length ? <Empty>No audit entries found.</Empty> : (
        <div className="scroll"><table>
          <thead><tr><th>When</th><th>Actor</th><th>Action</th><th>Entity</th><th>IP</th></tr></thead>
          <tbody>{data.map((l) => <tr key={l.id}><td>{fmtDate(l.createdAt)}</td><td>{l.actor?.name ?? l.actorId}</td><td>{l.action}</td><td>{l.entity} <span className="muted">{l.entityId}</span></td><td>{l.ip}</td></tr>)}</tbody>
        </table></div>)}
      <Pager meta={meta} onPage={setPage} />
    </>
  );
}
