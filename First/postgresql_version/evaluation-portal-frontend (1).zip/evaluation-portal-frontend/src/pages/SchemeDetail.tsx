import { FormEvent, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { api, downloadFile, errCode, errMsg } from '../api/client';
import { useFetch } from '../api/useFetch';
import { ErrorBox, Field, Loading, Modal, StatusBadge } from '../components/ui';
import { fmtDate } from '../api/types';

type Tab = 'summary' | 'detail' | 'comments' | 'versions';

export default function SchemeDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const base = `/teaching-schemes/${id}`;
  const scheme = useFetch<any>(base);
  const summary = useFetch<any>(`${base}/summary`);
  const comments = useFetch<any[]>(`${base}/comments`);
  const versions = useFetch<any[]>(`${base}/versions`);
  const [tab, setTab] = useState<Tab>('summary');
  const [msg, setMsg] = useState<{ ok: boolean; text: string }>();
  const [decision, setDecision] = useState<'approve' | 'return' | null>(null);

  const s = scheme.data;
  if (scheme.loading && !s) return <Loading />;
  if (!s) return <ErrorBox msg={scheme.error ?? 'Scheme not found'} />;

  const isOwner = user!.role === 'FACULTY' && s.courseAssignment?.facultyId === user!.id;
  const canEdit = isOwner && (s.status === 'DRAFT' || s.status === 'RETURNED_FOR_CORRECTION');
  const canReview = user!.role === 'HOD' && (s.status === 'SUBMITTED' || s.status === 'UNDER_REVIEW');
  const refresh = () => { scheme.reload(); summary.reload(); comments.reload(); versions.reload(); };

  const run = async (fn: () => Promise<any>, ok: string) => {
    setMsg(undefined);
    try { await fn(); setMsg({ ok: true, text: ok }); refresh(); }
    catch (e) { setMsg({ ok: false, text: errCode(e) === 'VALIDATION_FAILED' ? `Fix these before submitting: ${errMsg(e)}` : errMsg(e) }); }
  };

  const failed = (summary.data?.validation ?? summary.data?.validationResults ?? []).filter((c: any) => !(c.passed ?? c.status === 'PASS'));

  return (
    <>
      <div className="row between">
        <div>
          <h1>{s.courseAssignment?.course?.code} – {s.courseAssignment?.course?.title}</h1>
          <div className="row"><StatusBadge status={s.status} /><span className="muted">v{s.currentVersion ?? 0} · {s.courseAssignment?.faculty?.name} · {s.documentId ?? 'No document ID yet'}</span></div>
        </div>
        <div className="row">
          {canEdit && <Link className="btn ghost" to={`/schemes/${id}/edit`}>Edit</Link>}
          {canEdit && <button className="btn" onClick={() => run(() => api.post(`${base}/submit`), 'Submitted for review.')}>Submit for review</button>}
          {isOwner && s.status === 'DRAFT' && <button className="btn ghost" onClick={async () => { if (confirm('Delete this draft?')) { await api.del(base); history.back(); } }}>Delete draft</button>}
          {user!.role === 'HOD' && s.status === 'SUBMITTED' && <button className="btn ghost" onClick={() => run(() => api.get(`${base}/detailed`), 'Review started.')}>Start review</button>}
          {canReview && <button className="btn ok" onClick={() => setDecision('approve')}>Approve</button>}
          {canReview && <button className="btn danger" onClick={() => setDecision('return')}>Return</button>}
          {s.status === 'APPROVED' && <button className="btn" onClick={() => downloadFile(`${base}/pdf`, `${s.documentId ?? 'scheme'}.pdf`).catch((e) => setMsg({ ok: false, text: errMsg(e) }))}>Download PDF</button>}
        </div>
      </div>

      {msg && <div className={`alert ${msg.ok ? 'okk' : 'err'}`} role="status">{msg.text}</div>}
      {s.status === 'APPROVED' && <div className="alert okk">Approved {fmtDate(s.approvedAt)}. This scheme is locked.</div>}
      {s.status === 'RETURNED_FOR_CORRECTION' && <div className="alert warn">Returned for correction. Read the HOD's comment, edit, and submit again.</div>}

      <div className="tabs" role="tablist">
        {(['summary', 'detail', 'comments', 'versions'] as Tab[]).map((t) => <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{{ summary: 'Summary', detail: 'Full scheme', comments: `Comments (${comments.data?.length ?? 0})`, versions: 'Versions' }[t]}</button>)}
      </div>

      {tab === 'summary' && <Summary data={summary.data} loading={summary.loading} error={summary.error} failedCount={failed.length} />}
      {tab === 'detail' && <Detail s={s} />}
      {tab === 'comments' && <Comments base={base} list={comments.data} reload={comments.reload} locked={s.status === 'APPROVED'} />}
      {tab === 'versions' && <Versions base={base} list={versions.data} />}

      {decision && <DecisionModal kind={decision} onClose={() => setDecision(null)} onDone={(t) => { setDecision(null); setMsg({ ok: true, text: t }); refresh(); }} base={base} />}
    </>
  );
}

function Summary({ data, loading, error, failedCount }: { data: any; loading: boolean; error?: string; failedCount: number }) {
  if (loading && !data) return <Loading />;
  if (error) return <ErrorBox msg={error} />;
  const units: any[] = data?.units ?? data?.unitTable ?? [];
  const assess: any[] = data?.assessment ?? data?.assessmentTable ?? data?.assessmentComponents ?? [];
  const checks: any[] = data?.validation ?? data?.validationResults ?? [];
  return (
    <>
      <div className="grid">
        <div className="stat"><b>{data?.totalPlannedHours ?? data?.totals?.plannedHours ?? '—'}</b><span className="muted">Planned hours</span></div>
        <div className="stat"><b>{data?.totalAssessmentMarks ?? data?.totals?.assessmentMarks ?? '—'}</b><span className="muted">Assessment marks</span></div>
        <div className="stat"><b>{failedCount}</b><span className="muted">Failed checks</span></div>
      </div>
      <div className="card"><h2>Units</h2>
        <div className="scroll"><table><thead><tr><th>Unit</th><th>Hours</th><th>Outcomes</th><th>Weeks</th></tr></thead>
          <tbody>{units.map((u, i) => <tr key={i}><td>{u.title}</td><td>{u.hours ?? u.plannedHours}</td><td>{(u.cos ?? u.courseOutcomes ?? []).join?.(', ')}</td><td>{u.weeks ?? `${u.startWeek}–${u.endWeek}`}</td></tr>)}</tbody></table></div></div>
      <div className="card"><h2>Assessment</h2>
        <div className="scroll"><table><thead><tr><th>Component</th><th>Type</th><th>Marks</th></tr></thead>
          <tbody>{assess.map((a, i) => <tr key={i}><td>{a.name}</td><td>{a.type}</td><td>{a.maxMarks ?? a.marks}</td></tr>)}</tbody></table></div></div>
      <div className="card"><h2>Validation</h2>
        {checks.map((c, i) => { const ok = c.passed ?? c.status === 'PASS'; return <div key={i} className={`check ${ok ? 'pass' : 'fail'}`}><span className="dot">{ok ? '✓' : '✕'}</span><span>{c.name ?? c.check ?? c.code}{c.message ? ` – ${c.message}` : ''}</span></div>; })}
      </div>
    </>
  );
}

function Detail({ s }: { s: any }) {
  return (
    <>
      {s.facultyNotes && <div className="card"><h2>Faculty notes</h2><p>{s.facultyNotes}</p></div>}
      <div className="card"><h2>Course outcomes</h2>{(s.courseOutcomes ?? []).map((c: any) => <p key={c.id ?? c.code}><strong>{c.code}</strong> {c.description}</p>)}</div>
      {(s.units ?? []).map((u: any) => (
        <div className="card" key={u.id ?? u.number}>
          <h2>Unit {u.number}: {u.title}</h2><p className="muted">Weeks {u.startWeek}–{u.endWeek}{u.resources ? ` · ${u.resources}` : ''}</p>
          <table><thead><tr><th>Topic</th><th>Hours</th><th>Method</th></tr></thead>
            <tbody>{(u.topics ?? []).map((t: any) => <tr key={t.id ?? t.name}><td>{t.name}</td><td>{t.plannedHours}</td><td>{t.teachingMethod}</td></tr>)}</tbody></table>
        </div>))}
      <div className="card"><h2>References</h2>{(s.references ?? []).map((r: any) => <p key={r.id ?? r.citation}><span className="muted">{r.type}</span> {r.citation}</p>)}</div>
    </>
  );
}

function Comments({ base, list, reload, locked }: { base: string; list?: any[]; reload(): void; locked: boolean }) {
  const [body, setBody] = useState('');
  const [err, setErr] = useState<string>();
  const post = async (e: FormEvent) => { e.preventDefault(); setErr(undefined); try { await api.post(`${base}/comments`, { body }); setBody(''); reload(); } catch (x) { setErr(errMsg(x)); } };
  return (
    <>
      {(list ?? []).map((c) => (
        <div className="card" key={c.id}>
          <div className="row between"><strong>{c.author?.name ?? 'Unknown'}</strong><span className="muted">{c.type} · v{c.versionNumber} · {fmtDate(c.createdAt)}</span></div>
          <p>{c.body}</p>
        </div>))}
      {!list?.length && <p className="empty">No comments yet.</p>}
      {!locked && <form className="card" onSubmit={post}><ErrorBox msg={err} /><Field label="Add a comment"><textarea value={body} onChange={(e) => setBody(e.target.value)} required /></Field><button className="btn">Post comment</button></form>}
    </>
  );
}

function Versions({ base, list }: { base: string; list?: any[] }) {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const diff = useFetch<any>(from && to && from !== to ? `${base}/versions/compare` : null, { from, to });
  const opts = (list ?? []).map((v) => <option key={v.id} value={v.versionNumber}>Version {v.versionNumber}</option>);
  return (
    <>
      <div className="scroll"><table><thead><tr><th>Version</th><th>Created</th><th>By</th></tr></thead>
        <tbody>{(list ?? []).map((v) => <tr key={v.id}><td>v{v.versionNumber}</td><td>{fmtDate(v.createdAt)}</td><td>{v.createdBy?.name ?? v.createdById}</td></tr>)}</tbody></table></div>
      {(list?.length ?? 0) > 1 && (
        <div className="card"><h2>Compare versions</h2>
          <div className="row"><select style={{ maxWidth: 180 }} value={from} onChange={(e) => setFrom(e.target.value)}><option value="">From…</option>{opts}</select>
            <select style={{ maxWidth: 180 }} value={to} onChange={(e) => setTo(e.target.value)}><option value="">To…</option>{opts}</select></div>
          <ErrorBox msg={diff.error} />{diff.loading && <Loading />}{diff.data && <pre>{JSON.stringify(diff.data, null, 2)}</pre>}
        </div>)}
    </>
  );
}

function DecisionModal({ kind, base, onClose, onDone }: { kind: 'approve' | 'return'; base: string; onClose(): void; onDone(t: string): void }) {
  const [comment, setComment] = useState('');
  const [err, setErr] = useState<string>();
  const go = async (e: FormEvent) => {
    e.preventDefault();
    try { await api.post(`${base}/${kind}`, { comment: comment || undefined }); onDone(kind === 'approve' ? 'Scheme approved and locked.' : 'Scheme returned to the faculty.'); }
    catch (x) { setErr(errMsg(x)); }
  };
  return (
    <Modal title={kind === 'approve' ? 'Approve scheme' : 'Return for correction'} onClose={onClose}>
      <form onSubmit={go}><ErrorBox msg={err} />
        <Field label={kind === 'approve' ? 'Comment (optional)' : 'What needs to change?'}><textarea value={comment} onChange={(e) => setComment(e.target.value)} required={kind === 'return'} autoFocus /></Field>
        <button className={`btn ${kind === 'approve' ? 'ok' : 'danger'}`}>{kind === 'approve' ? 'Approve scheme' : 'Return scheme'}</button>
      </form>
    </Modal>
  );
}
