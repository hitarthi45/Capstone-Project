import { FormEvent, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, errMsg } from '../api/client';
import { useFetch } from '../api/useFetch';
import { ErrorBox, Field, Loading } from '../components/ui';

/**
 * Payload assumption (centralised in toPayload): nested create/update body =
 * { courseAssignmentId, totalPlannedHours, totalAssessmentMarks, facultyNotes,
 *   courseOutcomes:[{code,description}],
 *   units:[{number,title,startWeek,endWeek,resources,topics:[{name,plannedHours,teachingMethod,coCodes:[]}]}],
 *   assessmentComponents:[{name,type,maxMarks,unitNumbers:[]}], references:[{type,citation}] }
 * Adjust here if the backend uses different field names.
 */
const blank = () => ({
  courseAssignmentId: '', totalPlannedHours: 0, totalAssessmentMarks: 100, facultyNotes: '',
  courseOutcomes: [{ code: 'CO1', description: '' }],
  units: [{ number: 1, title: '', startWeek: 1, endWeek: 2, resources: '', topics: [{ name: '', plannedHours: 1, teachingMethod: '', coCodes: [] as string[] }] }],
  assessmentComponents: [] as any[], references: [] as any[],
});

const fromApi = (s: any) => ({
  courseAssignmentId: s.courseAssignmentId, totalPlannedHours: s.totalPlannedHours, totalAssessmentMarks: s.totalAssessmentMarks, facultyNotes: s.facultyNotes ?? '',
  courseOutcomes: (s.courseOutcomes ?? []).map((c: any) => ({ code: c.code, description: c.description })),
  units: (s.units ?? []).map((u: any) => ({ number: u.number, title: u.title, startWeek: u.startWeek, endWeek: u.endWeek, resources: u.resources ?? '',
    topics: (u.topics ?? []).map((t: any) => ({ name: t.name, plannedHours: t.plannedHours, teachingMethod: t.teachingMethod ?? '', coCodes: t.coCodes ?? (t.courseOutcomes ?? t.cos ?? []).map((c: any) => c.code ?? c.courseOutcome?.code) })) })),
  assessmentComponents: (s.assessmentComponents ?? []).map((a: any) => ({ name: a.name, type: a.type, maxMarks: a.maxMarks, unitNumbers: a.unitNumbers ?? (a.units ?? []).map((u: any) => u.number ?? u.unit?.number) })),
  references: (s.references ?? []).map((r: any) => ({ type: r.type, citation: r.citation })),
});

const toPayload = (f: ReturnType<typeof blank>, isEdit: boolean) => {
  const { courseAssignmentId, ...rest } = f;
  return {
    ...(isEdit ? {} : { courseAssignmentId }), ...rest,
    totalPlannedHours: Number(f.totalPlannedHours), totalAssessmentMarks: Number(f.totalAssessmentMarks),
    units: f.units.map((u) => ({ ...u, number: Number(u.number), startWeek: Number(u.startWeek), endWeek: Number(u.endWeek), topics: u.topics.map((t) => ({ ...t, plannedHours: Number(t.plannedHours) })) })),
    assessmentComponents: f.assessmentComponents.map((a) => ({ ...a, maxMarks: Number(a.maxMarks) })),
  };
};

export default function SchemeEditor() {
  const { id } = useParams();
  const nav = useNavigate();
  const DRAFT_KEY = 'scheme-editor-draft';
  const [restored, setRestored] = useState(false);
  const [f, setF] = useState<any>(() => {
    if (id) return blank();
    try { const d = localStorage.getItem(DRAFT_KEY); if (d) return JSON.parse(d); } catch { /* ignore corrupt draft */ }
    return blank();
  });
  const [file, setFile] = useState<File | null>(null);
  const [err, setErr] = useState<string>();
  const [busy, setBusy] = useState(false);
  const existing = useFetch<any>(id ? `/teaching-schemes/${id}` : null);
  const assignments = useFetch<any[]>('/course-assignments', { limit: 100 });
  const validation = useFetch<any>(id ? `/teaching-schemes/${id}/validation` : null);

  useEffect(() => { if (existing.data) setF(fromApi(existing.data)); }, [existing.data]);
  // Autosave unsaved new schemes locally so a refresh or closed tab loses nothing.
  useEffect(() => { if (!id && localStorage.getItem(DRAFT_KEY)) setRestored(true); }, []);
  useEffect(() => {
    if (id) return;
    const t = setTimeout(() => localStorage.setItem(DRAFT_KEY, JSON.stringify(f)), 600);
    return () => clearTimeout(t);
  }, [f, id]);

  // Clone: copy structure of an earlier approved scheme, keeping the chosen course assignment.
  const approved = useFetch<any[]>(id ? null : '/teaching-schemes', { status: 'APPROVED', limit: 50 });
  const clone = async (srcId: string) => {
    if (!srcId) return;
    try {
      const r = await api.get(`/teaching-schemes/${srcId}`);
      setF((p: any) => ({ ...fromApi(r.data), courseAssignmentId: p.courseAssignmentId }));
    } catch (e) { setErr(errMsg(e)); }
  };

  const upd = (fn: (draft: any) => void) => setF((p: any) => { const n = structuredClone(p); fn(n); return n; });
  const topicHours = f.units.reduce((s: number, u: any) => s + u.topics.reduce((a: number, t: any) => a + Number(t.plannedHours || 0), 0), 0);
  const marks = f.assessmentComponents.reduce((s: number, a: any) => s + Number(a.maxMarks || 0), 0);

  const save = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setErr(undefined);
    try {
      const body = toPayload(f, !!id);
      const r = id ? await api.patch(`/teaching-schemes/${id}`, body) : await api.post('/teaching-schemes', body);
      const sid = id ?? r.data.id;
      if (file) { const fd = new FormData(); fd.append('file', file); await api.post(`/teaching-schemes/${sid}/attachment`, fd); }
      localStorage.removeItem(DRAFT_KEY);
      nav(`/schemes/${sid}`);
    } catch (e2) { setErr(errMsg(e2)); } finally { setBusy(false); }
  };

  if (id && existing.loading) return <Loading />;
  const checks: any[] = validation.data?.checks ?? (Array.isArray(validation.data) ? validation.data : []);

  return (
    <form onSubmit={save}>
      <h1>{id ? 'Edit teaching scheme' : 'New teaching scheme'}</h1>
      <ErrorBox msg={err || existing.error} />
      {restored && <div className="alert warn row between">Restored your unsaved draft.
        <button type="button" className="btn ghost sm" onClick={() => { localStorage.removeItem(DRAFT_KEY); setF(blank()); setRestored(false); }}>Discard draft</button></div>}
      {!id && (approved.data?.length ?? 0) > 0 && (
        <div className="card"><h2>Start from a previous scheme</h2>
          <p className="muted">Copy units, topics, outcomes and assessment from an approved scheme, then adjust.</p>
          <select defaultValue="" onChange={(e) => { if (confirm('Replace the current form with this scheme?')) clone(e.target.value); e.target.value = ''; }}>
            <option value="">Choose an approved scheme…</option>
            {approved.data!.map((a) => <option key={a.id} value={a.id}>{a.courseAssignment?.course?.code} – {a.courseAssignment?.course?.title} ({a.courseAssignment?.academicYear})</option>)}
          </select></div>)}

      <div className="card">
        <h2>Course</h2>
        <Field label="Course assignment">
          <select required disabled={!!id} value={f.courseAssignmentId} onChange={(e) => upd((d) => { d.courseAssignmentId = e.target.value; })}>
            <option value="">Select a course…</option>
            {(assignments.data ?? []).map((a) => <option key={a.id} value={a.id}>{a.course?.code} – {a.course?.title} ({a.academicYear})</option>)}
          </select>
        </Field>
        <div className="grid">
          <Field label="Total planned hours" hint={`Topics add up to ${topicHours} h`}><input type="number" min={0} value={f.totalPlannedHours} onChange={(e) => upd((d) => { d.totalPlannedHours = e.target.value; })} /></Field>
          <Field label="Total assessment marks" hint={`Components add up to ${marks}`}><input type="number" min={0} value={f.totalAssessmentMarks} onChange={(e) => upd((d) => { d.totalAssessmentMarks = e.target.value; })} /></Field>
        </div>
        <Field label="Notes for the HOD"><textarea value={f.facultyNotes} onChange={(e) => upd((d) => { d.facultyNotes = e.target.value; })} /></Field>
      </div>

      <div className="card">
        <div className="row between"><h2>Course outcomes</h2>
          <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.courseOutcomes.push({ code: `CO${d.courseOutcomes.length + 1}`, description: '' }))}>Add outcome</button></div>
        {f.courseOutcomes.map((c: any, i: number) => (
          <div className="row" key={i} style={{ marginBottom: '.5rem' }}>
            <input style={{ width: 90 }} value={c.code} onChange={(e) => upd((d) => { d.courseOutcomes[i].code = e.target.value; })} aria-label="Outcome code" required />
            <input className="grow" value={c.description} placeholder="What the student will be able to do" onChange={(e) => upd((d) => { d.courseOutcomes[i].description = e.target.value; })} aria-label="Outcome description" required />
            <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.courseOutcomes.splice(i, 1))}>Remove</button>
          </div>))}
      </div>

      <div className="card">
        <div className="row between"><h2>Units and topics</h2>
          <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.units.push({ number: d.units.length + 1, title: '', startWeek: 1, endWeek: 1, resources: '', topics: [{ name: '', plannedHours: 1, teachingMethod: '', coCodes: [] }] }))}>Add unit</button></div>
        {f.units.map((u: any, ui: number) => (
          <div className="unit" key={ui}>
            <div className="row">
              <Field label="Unit no."><input type="number" style={{ width: 80 }} value={u.number} onChange={(e) => upd((d) => { d.units[ui].number = e.target.value; })} /></Field>
              <div className="grow"><Field label="Title"><input required value={u.title} onChange={(e) => upd((d) => { d.units[ui].title = e.target.value; })} /></Field></div>
              <Field label="Start week"><input type="number" style={{ width: 90 }} value={u.startWeek} onChange={(e) => upd((d) => { d.units[ui].startWeek = e.target.value; })} /></Field>
              <Field label="End week"><input type="number" style={{ width: 90 }} value={u.endWeek} onChange={(e) => upd((d) => { d.units[ui].endWeek = e.target.value; })} /></Field>
            </div>
            <Field label="Resources"><input value={u.resources} onChange={(e) => upd((d) => { d.units[ui].resources = e.target.value; })} /></Field>
            {u.topics.map((t: any, ti: number) => (
              <div key={ti} style={{ borderTop: '1px solid var(--line)', paddingTop: '.5rem' }}>
                <div className="topic">
                  <input required placeholder="Topic" value={t.name} onChange={(e) => upd((d) => { d.units[ui].topics[ti].name = e.target.value; })} aria-label="Topic name" />
                  <input type="number" min={0} value={t.plannedHours} onChange={(e) => upd((d) => { d.units[ui].topics[ti].plannedHours = e.target.value; })} aria-label="Planned hours" />
                  <input placeholder="Teaching method" value={t.teachingMethod} onChange={(e) => upd((d) => { d.units[ui].topics[ti].teachingMethod = e.target.value; })} aria-label="Teaching method" />
                  <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.units[ui].topics.splice(ti, 1))}>Remove</button>
                </div>
                <div className="chips" aria-label="Linked outcomes">
                  {f.courseOutcomes.map((c: any) => (
                    <button type="button" key={c.code} className={`chip ${t.coCodes.includes(c.code) ? 'on' : ''}`} aria-pressed={t.coCodes.includes(c.code)}
                      onClick={() => upd((d) => { const a = d.units[ui].topics[ti].coCodes; const k = a.indexOf(c.code); k >= 0 ? a.splice(k, 1) : a.push(c.code); })}>{c.code}</button>))}
                </div>
              </div>))}
            <div className="row" style={{ marginTop: '.75rem' }}>
              <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.units[ui].topics.push({ name: '', plannedHours: 1, teachingMethod: '', coCodes: [] }))}>Add topic</button>
              <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.units.splice(ui, 1))}>Remove unit</button>
            </div>
          </div>))}
      </div>

      <div className="card">
        <div className="row between"><h2>Assessment</h2>
          <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.assessmentComponents.push({ name: '', type: 'INTERNAL', maxMarks: 10, unitNumbers: [] }))}>Add component</button></div>
        {f.assessmentComponents.map((a: any, i: number) => (
          <div key={i} style={{ marginBottom: '.75rem' }}>
            <div className="row">
              <input className="grow" required placeholder="Name (e.g. Mid-semester exam)" value={a.name} onChange={(e) => upd((d) => { d.assessmentComponents[i].name = e.target.value; })} aria-label="Component name" />
              <input style={{ width: 140 }} placeholder="Type" value={a.type} onChange={(e) => upd((d) => { d.assessmentComponents[i].type = e.target.value; })} aria-label="Component type" />
              <input style={{ width: 90 }} type="number" min={0} value={a.maxMarks} onChange={(e) => upd((d) => { d.assessmentComponents[i].maxMarks = e.target.value; })} aria-label="Max marks" />
              <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.assessmentComponents.splice(i, 1))}>Remove</button>
            </div>
            <div className="chips" style={{ marginTop: '.4rem' }}>
              {f.units.map((u: any) => <button type="button" key={u.number} aria-pressed={a.unitNumbers.includes(Number(u.number))} className={`chip ${a.unitNumbers.includes(Number(u.number)) ? 'on' : ''}`}
                onClick={() => upd((d) => { const arr = d.assessmentComponents[i].unitNumbers; const n = Number(u.number); const k = arr.indexOf(n); k >= 0 ? arr.splice(k, 1) : arr.push(n); })}>Unit {u.number}</button>)}
            </div>
          </div>))}
      </div>

      <div className="card">
        <div className="row between"><h2>References and attachment</h2>
          <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.references.push({ type: 'TEXTBOOK', citation: '' }))}>Add reference</button></div>
        {f.references.map((r: any, i: number) => (
          <div className="row" key={i} style={{ marginBottom: '.5rem' }}>
            <select style={{ width: 150 }} value={r.type} onChange={(e) => upd((d) => { d.references[i].type = e.target.value; })}><option value="TEXTBOOK">Textbook</option><option value="REFERENCE">Reference</option></select>
            <input className="grow" required placeholder="Citation" value={r.citation} onChange={(e) => upd((d) => { d.references[i].citation = e.target.value; })} />
            <button type="button" className="btn ghost sm" onClick={() => upd((d) => d.references.splice(i, 1))}>Remove</button>
          </div>))}
        <Field label="Attachment" hint="PDF or DOCX, up to 10 MB"><input type="file" accept=".pdf,.docx" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></Field>
      </div>

      {id && checks.length > 0 && (
        <div className="card"><h2>Checks from the last save</h2>
          {checks.map((c, i) => { const ok = c.passed ?? c.status === 'PASS'; return <div key={i} className={`check ${ok ? 'pass' : 'fail'}`}><span className="dot">{ok ? '✓' : '✕'}</span><span>{c.name ?? c.check ?? c.code}{c.message ? ` – ${c.message}` : ''}</span></div>; })}
        </div>)}

      <div className="sticky row">
        <button className="btn" disabled={busy}>{busy ? 'Saving…' : 'Save scheme'}</button>
        <button type="button" className="btn ghost" onClick={() => nav(-1)}>Cancel</button>
        {topicHours !== Number(f.totalPlannedHours) && <span className="muted">Topic hours ({topicHours}) differ from total ({f.totalPlannedHours}).</span>}
        {f.assessmentComponents.length > 0 && marks !== Number(f.totalAssessmentMarks) && <span className="muted">Assessment marks ({marks}) differ from total ({f.totalAssessmentMarks}).</span>}
      </div>
    </form>
  );
}
