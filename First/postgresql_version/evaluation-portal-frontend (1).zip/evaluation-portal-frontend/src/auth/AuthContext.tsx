import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { api } from '../api/client';
import { Role, User } from '../api/types';

interface Ctx { user: User | null; loading: boolean; login(email: string, password: string): Promise<void>; logout(): void }
const AuthCtx = createContext<Ctx>(null as any);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(!!localStorage.getItem('token'));

  useEffect(() => {
    if (!localStorage.getItem('token')) return;
    api.get<User>('/auth/me').then((r) => setUser(r.data)).catch(() => localStorage.removeItem('token')).finally(() => setLoading(false));
  }, []);

  const login = async (email: string, password: string) => {
    const r = await api.post('/auth/login', { email, password });
    // Assumption: login returns { accessToken | token, user? }
    localStorage.setItem('token', r.data.accessToken ?? r.data.token);
    setUser(r.data.user ?? (await api.get<User>('/auth/me')).data);
  };
  const logout = () => { localStorage.removeItem('token'); setUser(null); };
  return <AuthCtx.Provider value={{ user, loading, login, logout }}>{children}</AuthCtx.Provider>;
}

export const hasRole = (u: User | null, ...roles: Role[]) => !!u && roles.includes(u.role);
