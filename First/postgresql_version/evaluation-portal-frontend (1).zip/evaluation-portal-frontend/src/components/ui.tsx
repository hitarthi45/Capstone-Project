import { ReactNode } from 'react';
import { Status, STATUS_LABEL } from '../api/types';

export const StatusBadge = ({ status }: { status: Status }) => <span className={`badge s-${status}`}>{STATUS_LABEL[status] ?? status}</span>;
export const Loading = () => <p className="muted pad">Loading…</p>;
export const ErrorBox = ({ msg }: { msg?: string }) => (msg ? <div className="alert err" role="alert">{msg}</div> : null);
export const Empty = ({ children }: { children: ReactNode }) => <p className="empty">{children}</p>;

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="field"><span>{label}</span>{children}{hint && <small className="muted">{hint}</small>}</label>;
}

export function Pager({ meta, onPage }: { meta?: any; onPage(p: number): void }) {
  if (!meta || !meta.totalPages || meta.totalPages <= 1) return null;
  return (
    <div className="pager">
      <button className="btn ghost" disabled={meta.page <= 1} onClick={() => onPage(meta.page - 1)}>Previous</button>
      <span className="muted">Page {meta.page} of {meta.totalPages}</span>
      <button className="btn ghost" disabled={meta.page >= meta.totalPages} onClick={() => onPage(meta.page + 1)}>Next</button>
    </div>
  );
}

export function Modal({ title, onClose, children }: { title: string; onClose(): void; children: ReactNode }) {
  return (
    <div className="overlay" onMouseDown={onClose}>
      <div className="modal" role="dialog" aria-label={title} onMouseDown={(e) => e.stopPropagation()}>
        <div className="row between"><h2>{title}</h2><button className="btn ghost" onClick={onClose}>Close</button></div>
        {children}
      </div>
    </div>
  );
}
