import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useFetch } from '../api/useFetch';

export default function Layout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const { data } = useFetch<any[]>('/notifications');
  const unread = (data ?? []).filter((n) => !n.isRead).length;
  const admin = user?.role === 'ADMIN';
  const link = (to: string, label: string) => <NavLink to={to} end={to === '/'}>{label}</NavLink>;

  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">Evaluation Portal</div>
        <nav>
          {link('/', 'Dashboard')}
          {link('/schemes', admin ? 'All schemes' : user?.role === 'HOD' ? 'Department schemes' : 'My schemes')}
          {user?.role !== 'FACULTY' && link('/analytics', 'Analytics')}
          {link('/notifications', unread ? `Notifications (${unread})` : 'Notifications')}
          {admin && <>
            <div className="navhead">Administration</div>
            {link('/admin/users', 'Users')}
            {link('/admin/departments', 'Departments')}
            {link('/admin/programs', 'Programs')}
            {link('/admin/semesters', 'Semesters')}
            {link('/admin/courses', 'Courses')}
            {link('/admin/course-assignments', 'Course assignments')}
            {link('/admin/audit-logs', 'Audit log')}
          </>}
        </nav>
        <div className="me">
          <strong>{user?.name}</strong><span className="muted">{user?.role}</span>
          <button className="btn ghost" onClick={() => { logout(); nav('/login'); }}>Sign out</button>
        </div>
      </aside>
      <main className="main"><Outlet /></main>
    </div>
  );
}
