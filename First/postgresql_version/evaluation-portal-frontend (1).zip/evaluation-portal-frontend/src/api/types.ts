export type Role = 'ADMIN' | 'HOD' | 'FACULTY';
export type Status = 'DRAFT' | 'SUBMITTED' | 'UNDER_REVIEW' | 'APPROVED' | 'RETURNED_FOR_CORRECTION';
export interface User { id: string; name: string; email: string; role: Role; departmentId?: string | null }
export const STATUS_LABEL: Record<Status, string> = {
  DRAFT: 'Draft', SUBMITTED: 'Submitted', UNDER_REVIEW: 'Under review', APPROVED: 'Approved', RETURNED_FOR_CORRECTION: 'Returned',
};
export const fmtDate = (d?: string | null) => (d ? new Date(d).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—');
