import axios from 'axios';

// Backend envelope: { success, data, message, meta? } | { success:false, error:{code,message,details?} }
export const http = axios.create({ baseURL: import.meta.env.VITE_API_URL || '/api/v1' });

http.interceptors.request.use((c) => {
  const t = localStorage.getItem('token');
  if (t) c.headers.Authorization = `Bearer ${t}`;
  return c;
});
http.interceptors.response.use((r) => r, (e) => {
  if (e.response?.status === 401 && !location.pathname.startsWith('/login')) {
    localStorage.removeItem('token');
    location.href = '/login';
  }
  return Promise.reject(e);
});

export const errMsg = (e: any): string => e?.response?.data?.error?.message ?? e?.message ?? 'Something went wrong';
export const errCode = (e: any): string | undefined => e?.response?.data?.error?.code;

type Res<T> = { data: T; meta?: any };
const unwrap = async <T,>(p: Promise<any>): Promise<Res<T>> => { const r = await p; return { data: r.data.data, meta: r.data.meta }; };

export const api = {
  get: <T = any,>(u: string, params?: any) => unwrap<T>(http.get(u, { params })),
  post: <T = any,>(u: string, body?: any) => unwrap<T>(http.post(u, body)),
  patch: <T = any,>(u: string, body?: any) => unwrap<T>(http.patch(u, body)),
  del: <T = any,>(u: string) => unwrap<T>(http.delete(u)),
};

export async function downloadFile(url: string, name: string) {
  const r = await http.get(url, { responseType: 'blob' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(r.data);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}
