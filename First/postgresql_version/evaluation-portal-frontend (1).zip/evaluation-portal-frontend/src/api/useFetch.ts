import { useEffect, useState } from 'react';
import { api, errMsg } from './client';

/** Fetch a GET endpoint; pass null as url to skip. Call reload() after mutations. */
export function useFetch<T = any>(url: string | null, params?: any) {
  const [s, set] = useState<{ data?: T; meta?: any; loading: boolean; error?: string }>({ loading: !!url });
  const [tick, setTick] = useState(0);
  const key = JSON.stringify([url, params]);
  useEffect(() => {
    if (!url) return;
    let live = true;
    set((p) => ({ ...p, loading: true, error: undefined }));
    api.get<T>(url, params)
      .then((r) => live && set({ data: r.data, meta: r.meta, loading: false }))
      .catch((e) => live && set({ loading: false, error: errMsg(e) }));
    return () => { live = false; };
  }, [key, tick]);
  return { ...s, reload: () => setTick((x) => x + 1) };
}
