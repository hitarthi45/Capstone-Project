import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './auth/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import SchemeList from './pages/SchemeList';
import SchemeEditor from './pages/SchemeEditor';
import SchemeDetail from './pages/SchemeDetail';
import Notifications from './pages/Notifications';
import Analytics from './pages/Analytics';
import AuditLogs from './pages/AuditLogs';
import ResourcePage from './pages/ResourcePage';
import { adminResources } from './pages/adminConfig';
import { Loading } from './components/ui';

export default function App() {
  const { user, loading } = useAuth();
  if (loading) return <Loading />;
  if (!user) return <Routes><Route path="/login" element={<Login />} /><Route path="*" element={<Navigate to="/login" replace />} /></Routes>;
  const admin = user.role === 'ADMIN';
  return (
    <Routes>
      <Route path="/login" element={<Navigate to="/" replace />} />
      <Route element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="schemes" element={<SchemeList />} />
        {user.role === 'FACULTY' && <Route path="schemes/new" element={<SchemeEditor />} />}
        {user.role === 'FACULTY' && <Route path="schemes/:id/edit" element={<SchemeEditor />} />}
        <Route path="schemes/:id" element={<SchemeDetail />} />
        {user.role !== 'FACULTY' && <Route path="analytics" element={<Analytics />} />}
        <Route path="notifications" element={<Notifications />} />
        {admin && adminResources.map((r) => <Route key={r.path} path={`admin/${r.path}`} element={<ResourcePage cfg={r} />} />)}
        {admin && <Route path="admin/audit-logs" element={<AuditLogs />} />}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
