import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
// In dev, /api/v1 is proxied to the backend so no CORS setup is needed.
export default defineConfig({ plugins: [react()], server: { port: 5173, proxy: { '/api': 'http://localhost:4000' } } });
