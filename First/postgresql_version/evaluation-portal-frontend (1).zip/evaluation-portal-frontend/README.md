# Evaluation Portal – Frontend (Phase 1)

React 18 + TypeScript + Vite. Talks to the Phase 1 backend at `/api/v1`.

## Run
```bash
npm install
cp .env.example .env     # optional; dev uses the Vite proxy to http://localhost:4000
npm run dev              # http://localhost:5173
npm run build            # typecheck + production build
```

## Structure
```
src/
  api/         client.ts (axios + envelope unwrap), useFetch.ts, types.ts
  auth/        AuthContext.tsx (JWT, /auth/me, role helper)
  components/  Layout.tsx (role-based nav), ui.tsx (badge, modal, pager, field)
  pages/       Login, Dashboard (faculty/hod/admin), SchemeList, SchemeEditor,
               SchemeDetail (summary, full view, comments, versions, approve/return, PDF),
               Notifications, AuditLogs, ResourcePage + adminConfig (all admin CRUD)
```

## Assumptions to check against docs/API.md
- Login returns `{ accessToken | token, user? }`; list meta is `{ page, totalPages }`.
- Nested scheme payload shape is defined in one place: `toPayload` / `fromApi` in `SchemeEditor.tsx`.
- Summary/dashboard/validation response fields are read defensively; adjust names in `SchemeDetail.tsx` once the OpenAPI file exists.
- Role-based UI is convenience only; the backend enforces RBAC.

## Analytics endpoint contract (needs adding to the backend)
`GET /analytics/department` (HOD, own department) and `GET /analytics/overview` (ADMIN) return
`{ statusCounts, totalSchemes, avgReviewHours, returnRate, turnaroundTrend[{label,hours}], hoursByCourse[{course,hours}], pendingFaculty[{name,drafts,returned}] }`.
Every field is optional; the page draws only what it receives.

## Faculty convenience features
- New scheme: "Start from a previous scheme" copies an approved scheme's structure.
- New scheme drafts autosave in the browser (localStorage) and are restored after a refresh.
